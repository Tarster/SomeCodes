import java.util.*;
public class TestMain{
	
	
    public static HashMap<String,ArrayList<String>> retrieveStudentInfo(ArrayList<Student> al) {
       // implement the required business logic
    	HashMap<String,ArrayList<String>> res=new HashMap<String,ArrayList<String>>();
    	for(int i=0;i<al.size();i++){
    	    if(res.get(al.get(i).getSchoolName())==null){
    	        ArrayList<String> tmp=new ArrayList<>();
    	        tmp.add(al.get(i).getStudName());
    	        res.put(al.get(i).getSchoolName(),tmp);
    	    }else{
    	        ArrayList<String> tmp=res.get(al.get(i).getSchoolName());
    	        tmp.add(al.get(i).getStudName());
    	        res.put(al.get(i).getSchoolName(),tmp);
    	    }
    	}
    	return res;
    }
    
    public static void main(String[] args)
    {
        Student s1=new Student();
        s1.setStudId(1);
        s1.setStudName("John");
        s1.setSchoolName("ZEE");
        Student s2=new Student();
        s2.setStudId(2);
        s2.setStudName("Tom");
        s2.setSchoolName("ZEE");
        Student s3=new Student();
        s3.setStudId(3);
        s3.setStudName("Peter");
        s3.setSchoolName("BEE");
        Student s4=new Student();
        s4.setStudId(4);
        s4.setStudName("Rose");
        s4.setSchoolName("OX-FO");
        Student s5=new Student();
        s5.setStudId(5);
        s5.setStudName("Alice");
        s5.setSchoolName("ZEE");
       
       //invoke the retrieveStudentInfo method and display the result
       ArrayList<Student> al=new ArrayList<Student>();
       al.add(s1);
       al.add(s2);
       al.add(s3);
       al.add(s4);
       al.add(s5);
       TestMain t=new TestMain();
       HashMap<String,ArrayList<String>> res=t.retrieveStudentInfo(al);
       for(Map.Entry<String,ArrayList<String>> entry:res.entrySet()){
           System.out.println(entry.getKey());
           ArrayList<String> tmp=entry.getValue();
           for(int i=0;i<tmp.size();i++){
               System.out.println(tmp.get(i));
           }
       }
       
    }
    
    
}
import java.util.*;
public class TestMain
{
    public static void main(String[] args)
    {
        Symposium sym=new Symposium();
        Scanner sc=new Scanner(System.in);
        int choice;
        do{
            System.out.println("1.Register Student");
            System.out.println("2.Display all Student Details");
            System.out.println("3.Display Student Details based on Department Name");
            System.out.println("4.Display total Count of Students - by Department Name");
            System.out.println("5.Exit");
            System.out.println("Enter your choice:");
            choice=sc.nextInt();
            sc.nextLine();
            switch(choice){
                case 1:
                    System.out.println("Enter the Student Id:");
                    int id=sc.nextInt();
                    sc.nextLine();
                    System.out.println("Enter the Student name:");
                    String name=sc.nextLine();
                    System.out.println("Enter the department Name:");
                    String deptname=sc.nextLine();
                    Student s=new Student();
                    s.setStudId(id);
                    s.setStudName(name);
                    s.setDeptName(deptname);
                    sym.addStudent(s);
                    break;
                case 2:
                    ArrayList<Student> e=sym.viewAllStudentDetails();
                    if(sym.isEmpty())
                        System.out.println("No Student Registered");
                    else 
                        for(Student i:e){
                            System.out.println("Student Id:"+i.getStudId());
                            System.out.println("Student Name:"+i.getStudName());
                            System.out.println("Department Name:"+i.getDeptName());
                        }
                    break;
                case 3:
                    System.out.println("Enter the Department Name : ");
                    String dname=sc.nextLine();
                    if(dname.equalsIgnoreCase("ECE") || dname.equalsIgnoreCase("EEE") || dname.equalsIgnoreCase("CS") || dname.equalsIgnoreCase("IT")){
                        if(sym.totalStudents(dname)==0)
                        System.out.println("No Students enrolled");
                        else{
                            ArrayList<Student> l=sym.viewStudentInfoByDept(dname);
                            for(Student i:l){
                                System.out.println("Student Id:"+i.getStudId());
                                System.out.println("Student Name:"+i.getStudName());
                                System.out.println("Department Name:"+i.getDeptName());
                            }
                        }
                    }else
                        System.out.println("Department not eligible for Symposium");
                        break;
                case 4:
                    System.out.println("Enter the Department Name : ");
                    String dename=sc.nextLine();
                    System.out.println("Total No of Student:"+sym.totalStudents(dename));
                    break;
                case 5:
                    break;
            }
        }while(choice!=5);
    }
}
import java.util.*;
public class Symposium{
    
    //complete the required business logic
    private ArrayList<Student> studentList=new ArrayList<Student>();
    public void setStudentList(ArrayList<Student> studentList){
        this.studentList=studentList;
    }
    public ArrayList<Student> getStudentList(){
        return studentList;
    }
    public void addStudent(Student aobj){
        studentList.add(aobj);
    }
    public boolean isEmpty(){
        if(studentList.isEmpty())
            return true;
        else
            return false;
    }
    public ArrayList<Student> viewAllStudentDetails(){
        return studentList;
    }
    public ArrayList<Student> viewStudentInfoByDept(String deptName){
        ArrayList<Student> Student=new ArrayList<Student>();
        for(int i=0;i<studentList.size();i++){
            if(studentList.get(i).getDeptName().equalsIgnoreCase(deptName))
            Student.add(studentList.get(i));
    }
    return Student;
  }

  public int totalStudents(String deptName){
      int count=0;
      for(int i=0;i<studentList.size();i++){
          if(studentList.get(i).getDeptName().equalsIgnoreCase(deptName))
          count++;
      }
      return count;
  }
    
}
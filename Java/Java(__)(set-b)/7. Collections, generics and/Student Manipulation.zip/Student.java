//Do not alter the Student class
public class Student {
	private int studId;
	private String studName;
	private String deptName;
	public int getStudId() {
		return studId;
	}
	
	public Student()
	{
	    
	}
	public void setStudId(int studId) {
		this.studId = studId;
	}
	public String getStudName() {
		return studName;
	}
	public void setStudName(String studName) {
		this.studName = studName;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	

}

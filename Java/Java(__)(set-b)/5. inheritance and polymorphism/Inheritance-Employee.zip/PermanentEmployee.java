public class PermanentEmployee extends Employee{
    
    private double basicSalary;
    private double hra;
    private double da;
    
    public double getBasicSalary(){
        return basicSalary;
    }
    public double getHra(){
        return hra;
    }
    public double getDa(){
        return da;
    }
    public void setBasicSalary(double basicSalary){
        this.basicSalary=basicSalary;
    }
    public void setHra(double hra){
        this.hra=hra;
    }
    public void setDa(double da){
        this.da=da;
    }
    public double calculateSalary(){
        int pf=800;
        double netSalary=basicSalary+hra+da-pf;
        return netSalary;
    }
    
}
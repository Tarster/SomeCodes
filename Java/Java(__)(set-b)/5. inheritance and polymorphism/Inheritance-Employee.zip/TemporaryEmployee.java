public class TemporaryEmployee extends Employee{
    private int noOfDays;
    private double wagePerDay;
    public int getNoOfDays(){
        return noOfDays;
    }
    public double getWagePerDay(){
        return wagePerDay;
    }
    public void setNoOfDays(int noOfDays){
        this.noOfDays=noOfDays;
    }
    public void setWagePerDay(double wagePerDay){
        this.wagePerDay=wagePerDay;
    }
    public double calculateSalary(){
        double netSalary=noOfDays*wagePerDay;;
        return netSalary;
    } 
}
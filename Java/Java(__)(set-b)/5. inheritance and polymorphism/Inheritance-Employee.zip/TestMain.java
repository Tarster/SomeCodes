import java.util.*;
public class TestMain{
    public static void main (String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("1.Salary for PermanentEmployee");
        System.out.println("2.Salary for TemporaryEmployee");
        int choice;
        int emp_id=0;
        for(int i=0;i<2;i++){
            System.out.println("Enter the choice:");
            choice=sc.nextInt();
            sc.nextLine();
            switch(choice){
                case 1:
                    System.out.println("Enter the Employee id:");
                    emp_id=sc.nextInt();
                    sc.nextLine();
                    System.out.println("Enter the Basic Salary:");
                    double Salary=sc.nextDouble();
                    System.out.println("Enter the HRA:");
                    double hra=sc.nextDouble();
                    System.out.println("Enter the DA:");
                    double da=sc.nextDouble();
                    PermanentEmployee pe=new PermanentEmployee();
                    pe.setEmpId(emp_id);
                    pe.setBasicSalary(Salary);
                    pe.setHra(hra);
                    pe.setDa(da);
                    double netsalary=pe.calculateSalary();
                    System.out.println("Your NetSalary is:"+netsalary);
                    break;
                case 2:
                    System.out.println("Enter the Employee id:");
                    emp_id=sc.nextInt();
                    sc.nextLine();
                    System.out.println("Enter the noOfDays:");
                    int noOfDays=sc.nextInt();
                    sc.nextLine();
                    System.out.println("Enter the wagePerDay:");
                    double wagePerDay=sc.nextDouble();
                    TemporaryEmployee te=new TemporaryEmployee();
                    te.setEmpId(emp_id);
                    te.setNoOfDays(noOfDays);
                    te.setWagePerDay(wagePerDay);
                    netsalary=te.calculateSalary();
                    System.out.println("Your NetSalary is:"+netsalary);
                    break;
            }
        }
    }
}
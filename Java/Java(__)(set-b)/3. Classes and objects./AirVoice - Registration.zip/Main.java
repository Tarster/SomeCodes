import java.util.Scanner;

public class Main{
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter the Name:");
        String nm = sc.nextLine();
        System.out.println("Enter the ContactNumber:");
        long no = sc.nextLong();
        System.out.println("Enter the EmailId:");
        String mail = sc.next();
        System.out.print("Age:");
        int age1 = sc.nextInt();
        if(age1<=0)
        {
            System.out.println("Invalid Input");
            return;
        }
        
        Customer obj = new Customer();
        obj.setCustomerName(nm);
        obj.setContactNumber(no);
        obj.setEmailId(mail);
        obj.setAge(age1);
        
        String NAME = obj.getCustomerName();
        long PHN = obj.getContactNumber();
        String EMAIL = obj.getEmailId();
        int AGE = obj.getAge();
        System.out.println("\nName:"+NAME);
        System.out.println("ContactNumber:"+PHN);
        System.out.println("EmailId:"+EMAIL);
        System.out.print("Age:"+AGE);
    }
}
public class Customer{
    
    private String customerName;
    private long contactNumber;
    private String emailId;
    private int age;
    
    /********  Getters  ******************/
    public String getCustomerName(){ 
        return customerName;
    }
    
    public long getContactNumber(){
        return contactNumber;
    }
    
    public String getEmailId(){
        return emailId;
    }
    
    public int getAge(){
        return age;
    }
    
    /**********  Setters  *******************/
    
    
    public void setCustomerName(String customerName){
        this.customerName = customerName;
    }
    
    public void setContactNumber(long contactNumber){
        this.contactNumber = contactNumber;
    }
    
    public void setEmailId(String emailId){
        this.emailId = emailId;
    }
    
    public void setAge(int age){
        this.age =age;
    }
    
   // public Customer(String customerName,long contactNumber, String emailId,int age) //Constructor
   public Customer()
    {
        this.customerName = customerName;
        this.contactNumber = contactNumber;
        this.emailId = emailId;
        this.age = age;
    }
}
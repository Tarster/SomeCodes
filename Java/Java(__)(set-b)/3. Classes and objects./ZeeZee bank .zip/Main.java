import java.util.*;

public class Main{
    public static void main (String[] args) {
        
        Scanner sc = new Scanner(System.in);
        int withdraw;
        long ac_num;
        double ac_bal;
        
        System.out.println("Enter the account number:");
        ac_num=sc.nextLong();
        System.out.println("Enter the available amount in the account:");
        ac_bal=sc.nextDouble();
        
        Account ac = new Account(ac_num, ac_bal);
        System.out.println("Enter the amount to be deposited:");
        ac.deposit(sc.nextDouble());
        System.out.println("Available balance is:"+String.format("%.2f",ac.getBalanceAmount()));
        System.out.println("Enter the amount to be withdrawn:");
        withdraw=ac.withdraw(sc.nextDouble());
        
        if(withdraw==-1){
            System.out.println("Insufficient balance");
            System.out.println("Available balance is:"+String.format("%.2f",ac.getBalanceAmount()));
        }else if(withdraw==1){
            System.out.println("Available balance is:"+String.format("%.2f",ac.getBalanceAmount()));
        }
    }
}
public class Account{
    
    private long accountNumber;
    private double balanceAmount;
    
    public Account(long accountNumber, double balanceAmount){
        this.accountNumber=accountNumber;
        this.balanceAmount=balanceAmount;
    }
    
    public int withdraw(double amount){
        if(balanceAmount<amount)
            return -1;
        else 
            balanceAmount-=amount;
                return 1;
    }
    
    public void deposit(double amount){
        balanceAmount+=amount;
    }
    
    public double getBalanceAmount(){
        return balanceAmount;
    }
}
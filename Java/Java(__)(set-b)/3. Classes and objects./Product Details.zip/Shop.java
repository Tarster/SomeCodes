public class Shop{
    
     private String[] productName;
     private int[] productQuantity;
     private float[] productPrice;
     
     public Shop(String[] productName, int[] productQuantity, float[] productPrice){
         this.productName=productName;
         this.productQuantity=productQuantity;
         this.productPrice=productPrice;
     }
     
     public String[] search(int productQuantity){
         int j=0;
         for(int i=0;i<this.productQuantity.length;i++){
             if(this.productQuantity[i]==productQuantity){
                 j++;
             }
         }
         String[] result=new String[j];
         j=0;
         for(int i=0;i<this.productQuantity.length;i++){
             if(this.productQuantity[i]==productQuantity){
                 result[j]=productName[i]+":"+productPrice[i];
                 j++;
             }
         }
         return result;
     }
     
     public String[] search(float productPrice){
         int j=0;
         for(int i=0;i<this.productPrice.length;i++){
             if(this.productPrice[i]==productPrice){
                 j++;
             }
         }
         String[] result=new String[j];
         j=0;
         for(int i=0;i<this.productPrice.length;i++){
             if(this.productPrice[i]==productPrice){
                 result[j]=productName[i]+":"+productQuantity[i];
                 j++;
             }
         }
         return result;
     }
     
     public String[] search(){
         
         int j=0;
         for(int i=0;i<this.productQuantity.length;i++){
             if(this.productQuantity[i]<=10){
                 j++;
             }
         }
         String[] result=new String[j];
         j=0;
         for(int i=0;i<this.productQuantity.length;i++){
             if(productQuantity[i]<=10){
                 result[j]=productName[i];
                 j++;
             }
         }
         return result;
     }
}








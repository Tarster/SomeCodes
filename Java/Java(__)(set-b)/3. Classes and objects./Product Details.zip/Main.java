import java.util.*;
public class Main{
    public static void main (String[] args) {
        
        Scanner sc=new Scanner(System.in);
        int num_products;
        System.out.println("Enter the number of products:");
        num_products=sc.nextInt();
        sc.nextLine();
        
        String[] p_name=new String[num_products];
        int[] p_Quantity=new int[num_products];
        float[] p_price=new float[num_products];
        
        System.out.println("Enter product names:");
        for(int i=0;i<num_products;i++)
            p_name[i]=sc.nextLine();
        
        System.out.println("Enter the price of each product:");
        for(int i=0;i<num_products;i++)
            p_price[i]=sc.nextFloat();
            
        System.out.println("Enter the quantity of each product:");
        for(int i=0;i<num_products;i++){
            p_Quantity[i]=sc.nextInt();
            sc.nextLine();
        }
        
        Shop s=new Shop(p_name,p_Quantity,p_price);
        
        System.out.println("Enter the product price to be searched:");
        float search_price=sc.nextFloat();
        System.out.println("Enter the product quantity to be searched:");
        int search_Quantity=sc.nextInt();
        System.out.println("Search based on price");
        String[] price = s.search(search_price);
        
        for(int i=0;i<price.length;i++)
            System.out.println(price[i]);
        System.out.println("Search based on quantity");
        String[] quantity=s.search(search_Quantity);
        
        for(int i=0;i<quantity.length;i++)
            System.out.println(quantity[i]);
        System.out.println("Products below re-ordered level");
        String[] level=s.search();
        for(int i=0;i<level.length;i++)
            System.out.println(level[i]);
    }
}

















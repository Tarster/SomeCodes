import java.util.*;

public class Main{
    public static void main(String[] args){
        
        Scanner sc = new Scanner(System.in);
        
        Product p=new Product();
        Category c=new Category();
        System.out.println("Enter the product id:");
        p.setProductId(sc.nextInt());
        sc.nextLine();
       
        System.out.println("Enter the product name:");
        p.setProductName(sc.nextLine());
        
        System.out.println("Enter the price:");
        p.setPrice(sc.nextDouble());
        
        System.out.println("Enter the category id:");
        c.setCategoryId(sc.nextInt());
        sc.nextLine();
        
        System.out.println("Enter the category name:");
        c.setCategoryName(sc.nextLine());
        p.setCategoryObj(c);
        p.applyCoupon();
        System.out.println("You need to pay "+String.format("%.2f",p.getPrice())+" for the "+c.getCategoryName()+" - "+p.getProductName());
    }
}
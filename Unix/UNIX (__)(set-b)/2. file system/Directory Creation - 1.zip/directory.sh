mkdir -p mydir/{animals/{mammals,reptiles},colors/{basic,blended},shape}
touch mydir/animals/{mammals/{bat,dog,platypus},reptiles/{snakes,crocodile,lizard}}
touch mydir/colors/{basic/{blue,green,red},blended/{orange,pink,yellow}}
touch mydir/shape/{circle,cube,square}
rm livingthings/animals/mammals/{jaguar,dog,tiger}
rm livingthings/animals/reptiles/{alligator,skink,turtle}
rmdir livingthings/animals/mammals
rmdir livingthings/animals/reptiles
